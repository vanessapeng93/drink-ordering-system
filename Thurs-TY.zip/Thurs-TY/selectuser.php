<?php  
 $connect = mysqli_connect("localhost", "root", "", "drinkordering");  
 $output = '';  
 $sql = "SELECT * FROM user ORDER BY id DESC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th width="10%">Id</th>  
                     <th width="20%">Name</th>  
                     <th width="20%">Date of Birth</th>  
					 <th width="20%">Mobile Number</th> 
					 <th width="20%">Email</th>  					 
                     <th width="10%">Add/Delete</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM user LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
                     <td class="name" data-id1="'.$row["id"].'" contenteditable="true">'.$row["name"].'</td>  
                     <td class="dob" data-id2="'.$row["id"].'" contenteditable="true">'.$row["dob"].'</td> 
					 <td class="hp" data-id3="'.$row["id"].'" contenteditable="true">'.$row["hp"].'</td>  
                     <td class="email" data-id4="'.$row["id"].'" contenteditable="true">'.$row["email"].'</td> 					 
                     <td><button type="button" name="delete_btn" data-id5="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">x</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="name" contenteditable="true"></td>  
                <td id="dob" contenteditable="true"></td>  
				<td id="hp" contenteditable="true"></td>  
                <td id="email" contenteditable="true"></td>  
                <td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
				<tr>  
					<td></td>  
					<td id="name" contenteditable="true"></td>  
					<td id="dob" contenteditable="true"></td>  
					<td id="hp" contenteditable="true"></td>  
					<td id="email" contenteditable="true"></td>  
					<td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
			   </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>