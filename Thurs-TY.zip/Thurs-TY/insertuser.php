<?php  
$connect = mysqli_connect("localhost", "root", "", "drinkordering");
$sql = "INSERT INTO user(name, dob,hp,email) VALUES('".$_POST["name"]."', '".$_POST["dob"]."','".$_POST["hp"]."','".$_POST["email"]."')";  
if(mysqli_query($connect, $sql))  
{  
     echo 'Data Inserted';  
}  
 ?>