<!DOCTYPE html>
<html lang="en">

  <body>
    
  <div class="footer">
      
    
            <div class="row">
                <div class="col-lg-12" >
                    &copy;  2018 
                </div>
            </div>
        </div>
    
  </body>
</html>