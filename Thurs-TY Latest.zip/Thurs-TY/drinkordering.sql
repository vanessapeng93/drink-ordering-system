-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2018 at 01:10 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drinkordering`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(800) NOT NULL,
  `category` varchar(200) NOT NULL,
  `price` double NOT NULL,
  `typeofremark` varchar(800) NOT NULL,
  `quantity` int(100) NOT NULL,
  `imageurl` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `description`, `category`, `price`, `typeofremark`, `quantity`, `imageurl`) VALUES
(6, 'Hazelnut Chocolate', 'Nothing is as heart-warming as rich chocolate mixed with the taste of roasted hazelnuts. Definitely a winning choice!', 'Chocolate', 5, 'none', 10, 'https://simpleveganblog.com/wp-content/uploads/2014/11/Hazelnut-chocolate-milk-3.jpg'),
(7, 'Chocolate Latte', 'This Yin & Yang concoction will get you shaking and stirring for more choco and milky goodness', 'Chocolate', 6, 'none', 10, 'https://www.julieseatsandtreats.com/wp-content/uploads/2015/10/White-Chocolate-Latte-Landscape.jpg'),
(8, 'Caramel Machiato', 'Freshly steamed milk with vanilla flavored syrup is marked with espresso and topped with caramel drizzle for an oh-so-sweet finish', 'Coffee', 15, 'none', 10, 'https://www.allfoodsrecipes.com/wp-content/uploads/2017/12/Caf%C3%A9-Caramel-Macchiato.jpg'),
(9, 'Hazelnut Milk Tea', 'Truly classic and undeniably nutty, all in favor of hazelnuts will take joy in this beverage for its well-balanced flavours.', 'Milk Tea', 7, 'none', 10, 'https://66.media.tumblr.com/06986cc324f75e037e7b8c1c4dd64f3f/tumblr_inline_n6npa1cpz41qgp297.jpg'),
(10, 'All Berry Bang', 'blueberries, strawberries, raspberries , apple juice, yogurt and Ice', 'Smoothie', 10, 'none', 10, 'https://beamingbaker.com/wp-content/uploads/2017/05/Triple-Berry-Smoothie-5-Ingredient-Paleo-Vegan-Gluten-Free-Dairy-Free-1.jpg'),
(11, 'Signature Chocolate', 'Chocolate milk and fresh dairy steamed together to create a fit for chocoholic. Topped with whipped cream and dusted with cocoa.Â ', 'Chocolate', 8, 'none', 10, 'http://www.starbucks.com.sg/images/default-source/menu/drinks/chocolate-beverages/signature-hot-chocolate.jpg?sfvrsn=6'),
(12, 'Caffe Mocha', 'combined with rich, full body espresso with bittersweet mocha sauce and steamed milk, topped with sweetened whipped cream. The classic coffee drink to satisfy your sweet tooth', 'Coffee', 16, 'none', 10, 'http://pinkmoose.net/wp-content/uploads/2016/06/Iced-Caff%C3%A8-Mocha.jpg'),
(13, 'Caramel Latte', 'indulgent, sweet caramel and silky steamed milk accentuate expresso forte natural caramel milk in this creamy desert like latte', 'Coffee', 15, 'none', 10, 'https://apumpkinandaprincess.com/wp-content/uploads/2014/08/Caramel-Marshmallow-Latte.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `shipping_address` varchar(100) DEFAULT NULL,
  `total_price` float NOT NULL,
  `status` varchar(100) DEFAULT 'pending',
  `approve` tinyint(4) DEFAULT '0',
  `paid` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `username`, `date`, `shipping_address`, `total_price`, `status`, `approve`, `paid`) VALUES
(2, '39', 'gaga', '2018-11-06 12:06:28', 'penang', 30, 'pending', 0, 0),
(3, '40', 'hauhan', '2018-11-06 12:07:57', 'penang', 31, 'pending', 0, 0),
(4, '40', 'hauhan', '2018-11-06 12:07:59', 'kedah', 11, 'pending', 0, 0),
(5, '42', 'Godzilla', '2018-11-06 12:08:01', 'kedah', 22, 'pending', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `price` float NOT NULL,
  `order_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `name`, `price`, `order_id`, `date`) VALUES
(1, 'Hazelnut Chocolate', 5, 1, '2018-11-06 04:01:27'),
(2, 'Hazelnut Chocolate', 5, 1, '2018-11-06 04:01:27'),
(3, 'Hazelnut Chocolate', 5, 1, '2018-11-06 04:01:27'),
(4, 'Hazelnut Chocolate', 5, 1, '2018-11-06 04:01:27'),
(5, 'Chocolate Latte', 6, 1, '2018-11-06 04:01:27'),
(6, 'Chocolate Latte', 6, 1, '2018-11-06 04:01:27'),
(7, 'Hazelnut Chocolate', 5, 2, '2018-11-06 04:03:08'),
(8, 'Hazelnut Milk Tea', 7, 2, '2018-11-06 04:03:09'),
(9, 'All Berry Bang', 10, 2, '2018-11-06 04:03:09'),
(10, 'Signature Chocolate', 8, 2, '2018-11-06 04:03:09'),
(11, 'Hazelnut Chocolate', 5, 3, '2018-11-06 04:11:41'),
(12, 'Hazelnut Chocolate', 5, 3, '2018-11-06 04:11:42'),
(13, 'Hazelnut Milk Tea', 7, 3, '2018-11-06 04:11:42'),
(14, 'Hazelnut Milk Tea', 7, 3, '2018-11-06 04:11:42'),
(15, 'Hazelnut Milk Tea', 7, 3, '2018-11-06 04:11:42'),
(16, 'Hazelnut Chocolate', 5, 4, '2018-11-06 04:27:12'),
(17, 'Chocolate Latte', 6, 4, '2018-11-06 04:27:12'),
(18, 'Hazelnut Chocolate', 5, 5, '2018-11-06 11:54:47'),
(19, 'Hazelnut Chocolate', 5, 5, '2018-11-06 11:54:47'),
(20, 'Chocolate Latte', 6, 5, '2018-11-06 11:54:47'),
(21, 'Chocolate Latte', 6, 5, '2018-11-06 11:54:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `confirmed` int(11) DEFAULT NULL,
  `confirmcode` int(11) DEFAULT NULL,
  `dob` date NOT NULL,
  `hp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `password`, `role`, `confirmed`, `confirmcode`, `dob`, `hp`) VALUES
(2, 'admin', 'vanessa', 'vanessapeng933@gmail.com', '123456', 'admin', 1, 0, '0000-00-00', '0229113411'),
(35, 'vanessapeng93', 'vanessapeng93', 'vanessapeng93@gmail.com', '123456', 'user', 1, 0, '0000-00-00', '0229113411'),
(37, 'linda', 'linda', 'norhaslindajamil9@gmail.com', '123456', 'user', 1, 0, '0000-00-00', '0229113411'),
(38, 'cheamhauhan', 'cheamhauhan', 'han@gmaiul.com', '123456', 'user', 1, 640465081, '0000-00-00', '0229113411'),
(39, 'gaga', 'gaga', 'hauhan1993@gmail.com', '123456', 'user', 1, 1642090789, '0000-00-00', '0229113411'),
(40, 'hanhan', 'hauhan', 'hauhan1993@gmail.com', '123456', 'user', 1, 2081489856, '0000-00-00', '0229113411'),
(41, 'medusa', 'gargon', 'medusa@gmail.com', '123456', 'user', 1, NULL, '2012-02-12', '0229113411'),
(42, 'Godzilla', 'Godzilla', 'Godzilla@gmail.com', '123456', 'user', 1, NULL, '2012-02-12', '0229113411');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
